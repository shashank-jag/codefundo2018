<?php
#require 'connect.inc.php';
echo 'hbjkhi'
#$result = mysql_query("SELECT * FROM `DEmandTable` where id='".$product_id['product_id']."'");
#$row = mysql_fetch_assoc( $result);
#echo $row['ProductName']
?>
