


<?php 
require 'header.php';?>
<div id="main_body">
<?php
require 'site_header.inc.php';
echo '<div id="content"class="col-sm-8">';
$query="SELECT * FROM `grocery` WHERE id='".$_REQUEST['item_id']."'";
$result = mysqli_query($link,$query);
$row_item = mysqli_fetch_assoc( $result);
echo '<div>
<div style="width:350px;float:left;">
<img style="width:300px;height:350px;"src="http://localhost/images/'.$row_item['image'].'"/>
</div>
<div style="float:left;">
<div class ="info">
<h2>'.$row_item['productname'].'</h2>';
if($row_item['characteristics']&2)
echo '<b >'.$row_item['description'].'</b><br><br>';
echo '<b>'.$row_item['my_price'].'&nbsp&nbsp&nbsp <strike style="font-size:15px;color:red;">Rs '.$row_item['actual_price'].'</strike></b><br>
</div><br><br>
<span class="qt"><span id="qt'.$row_item['id'].'"class="qty">Qty. <input type="number" min="1"id="qty1" value="1"style="width:50px;"></input>';
if($row_item['characteristics']&1)
echo '<select style="height:21px;"><option >kg</option><option >g</option></select></span>';
echo '&nbsp&nbsp<button class="onclick" id="'.$row_item['id'].'">&nbsp&nbspADD&nbsp&nbsp</button><br><br>
</span>
</div></div>';

?>
</div></div>
