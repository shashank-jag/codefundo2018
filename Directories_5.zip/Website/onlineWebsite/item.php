<?php
while( $row_item = mysql_fetch_assoc( $item)){
echo '<div class="item1" id="'.$row_item['id'].'">
<div id="productimg"><a href="item_page.php?item_id='.$row_item['id'].'">
<img id="prodimg" class=""src="http://localhost/images/'.$row_item['image'].'"/>
</a>
</div><br>
<div class ="info">
<b id="product_name">'.$row_item['productname'].'</b><br>';
if($row_item['characteristics']&2)
echo '<p style="font-size:15px;">'.$row_item['description'].'<p>';
else 
	echo '<br>';
echo '<b>Rs '.$row_item['my_price'].'&nbsp;&nbsp;&nbsp; <strike style="font-size:15px;color:red;">Rs '.$row_item['actual_price'].'</strike></b>
</div>
<span class="qt"><span id="qt'.$row_item['id'].'"class="qty">Qty. <input type="number" min="1"id="qty1" value="1"style="width:50px;"></input>';
if($row_item['characteristics']&1)
echo '<select style="height:21px;"><option >kg</option><option >g</option></select></span>';
echo '&nbsp&nbsp<button class="onclick" id="'.$row_item['id'].'">&nbsp&nbspADD&nbsp&nbsp</button><br><br>
</span>
</div>';
}
?>
