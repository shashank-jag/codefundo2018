<?php
if(isset($_POST['Email'])&&!empty($_POST['Password'])){
	$username = $_POST['Email'];
	$password = $_POST['Password'];
	if(!empty($username)&&!empty($password)){
		$query="SELECT * FROM `user` where `Email`='".$_POST['Email']."' AND `Password`='".md5($_POST['Password'])."'";
		if($run=mysql_query($query)){
			if(mysql_num_rows($run)==0){
				echo 'Invalid username/password combination';
			}else{
				$row_login=mysql_fetch_assoc($run);
				$_SESSION['user_id']=$row_login['user_id'];
				$_SESSION['Email']=$row_login['Email'];
				if(isset($_POST['Remeber']))
					setcookie('user_id',$row_login['user_id'],time()+(10 * 365 * 24 * 60 * 60));
					setcookie('Email',$row_login['Email'],time()+(10 * 365 * 24 * 60 * 60));
				header('Location: index.php');
			}
		}
		else{
			echo 'wrong';
		}
	}
}
?>

<div style="float:right;">
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#login">Login</button>

  <!-- Modal -->
  <div class="modal fade" id="login" role="dialog">
    <div class="modal-dialog"style="width:300px;height:400px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Login</h4>
        </div>
        <div class="modal-body">
          <form role="form"action="<?php echo $current_file;?>" id="login" method="POST" >
			<div class="form-group">
				<label for="email">Email</label>
				<input "type="email" id="username"  name="Email"class="form-control" placeholder="Enter email">
			</div>
			<div class="form-group">
				<label for="pwd">Password</label>
				<input type="password" name="Password"class="form-control" id="pwd" placeholder="Enter password">
			</div>
			<div class="checkbox">
				<label><input type="checkbox"id="ch"name="Remeber"> Remember me</label>
			</div >
			<button style="float:right;"type="submit" class="btn btn-info">Login</span></button>
		  </form>
        </div>
		<br><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-toggle="modal" data-dismiss="modal"data-target="#signup">Sign Up</button>
        </div>
      </div>
      
    </div>
  </div>
</div>