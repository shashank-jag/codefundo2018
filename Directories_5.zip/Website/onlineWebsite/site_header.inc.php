<style type="text/css">
nav {display: block;}
</style><br>
    <div id="sidebar"class="col-sm-2" style="z-index:997;">
    <div class="uiv2-left-navigation">
    <a href="index.php"><div class="uiv2-nav uiv2-pointer" id="uiv2-menu-bar">
    SHOP BY CATEGORY<span class="uiv2-nav-icon"></span>
    </div>
	</a>
    
    <div  class="uiv2-main-menu">
    <nav id="uiv2-main-menu">
    <ul>
	<?php 
	$result = mysql_query("SELECT DISTINCT `category` FROM `grocery`");
	while( $row = mysql_fetch_assoc( $result)){
		echo '<li class="normal">
		<a href="display_cat.php?cat='.$row['category'].'" class="top-category">'.$row['category'].'</a>
		<div class="uiv2-dropdown-box">
    <div class="uiv2-dropdown-inner">
    <div class="uiv2-dp-heading">
    <a href="display_cat.php?cat='.$row['category'].'">'.$row['category'].'</a></div>
    <div class="uiv2-dropdown-column">
    <ul>';
	$subcat = mysql_query("SELECT `productname`,`id` FROM `grocery` where category='".$row['category']."'");
	while($rowcat=mysql_fetch_assoc( $subcat))
		echo '<li><a href="item_page.php?item_id='.$rowcat['id'].'"> '.$rowcat['productname'].' </a></li>';
			
    	    
    echo'</ul>
    </div>
    </div>
    </div>
    </li>';
	}
	?>
	<!--<li class="normal">
    <a href="#" class="top-category">Fruits & Vegetables </a>
    <div class="uiv2-dropdown-box">
    <div class="uiv2-dropdown-inner">
    <div class="uiv2-dp-heading">
    <a href="#">Fruits & Vegetables</a></div>
    <div class="uiv2-dropdown-column">
    <ul>
	
    <li><a href="#"> Fruits1 </a></li>
			
    <li><a href="#">  Fruits2</a></li>
		
    <li><a href="#"> Fruits3 </a></li>
	
    <li><a href="#"> Fruits4 </a></li>
			
    <li><a href="#"> Fruits5 </a></li>
		    
    </ul>
    </div>
    </div>
    </div>
    </li>
	<li class="normal">
    <a href="#" class="top-category">Grocery </a>
    <div class="uiv2-dropdown-box">
    <div class="uiv2-dropdown-inner">
    <div class="uiv2-dp-heading">
    <a href="#">Grocery </a></div>
    <div class="uiv2-dropdown-column">
    <ul>
	
    <li><a href="#"> Grocery 1 </a></li>
			
    <li><a href="#">  Grocery 2</a></li>
		
    <li><a href="#"> Grocery 3 </a></li>
	
    <li><a href="#"> Grocery 4 </a></li>
			
    <li><a href="#"> Grocery 5 </a></li>
		    
    </ul>
    </div>
    </div>
    </div>
    </li>
	
    </div>
    </div>
    </div>
    </li>
	-->
	
	
	  </ul> 
</nav>	  
	  
 </div>
  
 </div>

</div>
