<?php
if(isset($_POST['email'])&&!empty($_POST['email'])){
	$query="INSERT INTO `user`(`user_id`, `Email`, `Password`, `Mobile`) VALUES('','".$_POST['email']."','".md5($_POST['Password'])."','".$_POST['Mobile']."')";
	//$query="SELECT * FROM `facebook`";
		if(mysql_query($query)){
				$runreg=mysql_query("SELECT * FROM `user` where `Mobile`='".$_POST['Mobile']."'");
				$row_reg=mysql_fetch_assoc($runreg);
				$_SESSION['user_id']=$row_reg['user_id'];
				$_SESSION['Email']=$row_reg['Email'];
				header('Location: index.php');
		}
		else
			echo "wrong";
}
?>
<div class="modal fade" id="signup" role="dialog">
    <div class="modal-dialog"style="width:300px;height:400px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sign Up</h4>
        </div>
        <div class="modal-body">
          <form role="form"action="<?php echo $current_file;?>" id="login" method="POST">
			<div class="form-group">
				<label for="email">Email</label>
				<input type="email" id="email"  name="email"class="form-control" placeholder="Enter email">
			</div>
			<div class="form-group">
				<label for="pwd">Password</label>
				<input type="password" id="password" name="Password"class="form-control" id="pwd" placeholder="Enter password">
			</div>
			<div class="form-group">
				<label for="pwd">Confirm Password</label>
				<input type="password" class="form-control" id="pwd" placeholder="Enter password">
			</div>
			<div class="form-group">
				<label for="pwd">Contact No.</label>
				<input type="text" id="contactno" name="Mobile" class="form-control" id="pwd" placeholder="Contact No.">
			</div>
			
			<button style="float:right;"type="submit" class="btn btn-info">Sign Up</span></button>
		  </form>
        </div>
		<br><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-toggle="modal" data-target="#login" data-dismiss="modal">Login</button>
        </div>
      </div>
      
    </div>
  </div>

<!--<form action ="register.php" method ="POST">
username<input type="text" name="username">
password<input type="text" name="password">
<input type='submit'>
</form>

-->
