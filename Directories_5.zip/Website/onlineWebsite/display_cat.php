<?php 
	require 'header.php';?>
<div id="main_body">	
<?php
	require 'site_header.inc.php';
	echo '<div class="col-sm-10">';
	$query="SELECT * FROM `grocery` WHERE category='".$_REQUEST['cat']."'";
	$item = mysql_query($query);
	require 'item.php';

?></div></div>