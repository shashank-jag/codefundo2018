
<!--<br><br><br>
<div class="cate">
<div class="cat">
<span style="font-size:30px; ">Category </span><button id="catbut"class="catbut">View All</button>
</div>
<div class="cat-item">
<?php //for($i=0;$i<4;$i++)require 'item.php';?>
</div>
</div>
-->



<?php
//require 'connect.inc.php';
if(!@mysql_connect('localhost','root','')||!@mysql_select_db('grocery'))
die('couldnt');
$result = mysql_query("SELECT DISTINCT `category` FROM `grocery`");
while( $row = mysql_fetch_assoc( $result)){
    
	echo "<br><br><br><div class='cate'>";
	echo "<div class='cat'>";
	echo '<span style="font-size:30px;">'.$row['category'].'</span><a href="display_cat.php?cat='.$row['category'].'"><span id="'.$row['category'].'"class="catbut">View All</span>';
	echo "</div>";
	echo "<div class='cat-item'>";
	$query="SELECT * FROM `grocery` WHERE category='".$row['category']."'";
	$item = mysql_query($query);
	require 'item.php';
	
    echo "</div>";
	echo "</div>";

}
?>

