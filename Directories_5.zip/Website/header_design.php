<div class="alert alert-success cart-success-alert" id="success-alert">
    Product successfully added to cart!
</div>
<div class="alert alert-success cart-success-alert" id="success-profile">
    Information Saved Successfully!
</div>
<div class="alert alert-success cart-success-alert" id="success-remove">
    Product successfully removed from your cart!
</div>
<div style="float:right;">
<?php 
	require 'core.inc.php';
	require 'connect.inc.php';
	if(loggedin()){
		include 'welcome.inc.php';
		//echo 'YOu are loigged <a href="logout.php">Logout</a>';
	}
	else if(isset($_COOKIE['user_id'])){
		$_SESSION['user_id']=$_COOKIE['user_id'];
		$_SESSION['Email']=$_COOKIE['Email'];
		include 'welcome.inc.php';
	}
	else{
		include 'loginform.inc.php';
		include 'register.php';
	}
	
?>
<br><br>
<div class="dropdown" style="float:right;">

<?php
if(isset($_SESSION['user_id'])){
	$no_of_products=mysqli_query($link,"SELECT `product_id`,`quantity` FROM `items_purchased` where user_id='".$_SESSION['user_id']."'");
	$price=0;
	$temp_n=4;
	while( $product_id = mysqli_fetch_assoc($no_of_products)&&$temp_n--){
		$result = mysqli_query($link,"SELECT `my_price` FROM `grocery` where id='".$product_id['product_id']."'");  
		$row = mysqli_fetch_assoc( $result);
		$price+=$row['my_price']*$product_id['quantity'];
	}
	echo '<div style="height:50px;"><img src="http://localhost/images/cart_icon.png" style="height:50px;width:50px;float:left">&nbsp&nbsp&nbsp Total : Rs <span id="total">'.$price.'</span>
	<br>&nbsp&nbsp&nbsp Items : <span id="total_items">'.mysqli_num_rows($no_of_products).'</span><br></div>';
}
else
	echo '<div style="height:50px;"><img src="http://localhost/images/cart_icon.png" style="height:50px;width:50px;float:left">&nbsp&nbsp&nbsp Total : Rs <span id="total">0</span>
	<br>&nbsp&nbsp&nbsp Items : <span id="total_items">0</span><br></div>';

?>  
  
  <div class="dropdown-content">
  <h4 class="modal-title">Your Cart</h4>
	<br>
    <div class="user_cart">
  <span id="cartist">
<?php
	if(isset($_SESSION['user_id'])){
		$no_of_products=mysqli_query($link,"SELECT `product_id`,`quantity` FROM `items_purchased` where user_id='".$_SESSION['user_id']."'");
		$price=0;
		if(mysqli_num_rows($no_of_products)>0){
		while( $product_id = mysqli_fetch_assoc($no_of_products)){
			$result = mysqli_query($link,"SELECT * FROM `grocery` where id='".$product_id['product_id']."'");  
			$row = mysqli_fetch_assoc( $result);
		echo '<div class="cart_item"style="height:60px;"><a href="item_page.php?item_id='.$row['id'].'"><img src="http://localhost/images/'.$row['image'].'"class="cart_img"></a>
		<img id="cros'.$row['id'].'" src="http://localhost/images/cross_icon.jpg"class="cart_cross_icon">
		<div style="float:right;"><button class="inc_dic"id="inc_dicb'.$row['id'].'">+</button><br>
		<div style="background-color:#E8E8E8;"class="inc_dic"id="inc_dic'.$row['id'].'">'.$product_id['quantity'].'</div><button class="inc_dic" id="inc_dicm'.$row['id'].'">-</button>
		</div>&nbsp&nbsp'.$row['productname'].'<br><b>&nbsp&nbspRs '.$row['my_price'].'&nbsp;&nbsp;&nbsp; <strike style="font-size:15px;color:red;">Rs '.$row['actual_price'].'</strike></b>
		</div><br>';
		$price+=$row['my_price']*$product_id['quantity'];
		}
		
		}else echo 'Your Cart is Empty';
	}
	else echo '<div>Please Login or Register to add items to cart</div>';
?>

	  </span>
	  </div>
	<br>
	<?php
	if(isset($_SESSION['user_id'])&&mysqli_num_rows($no_of_products)){
		echo '<a href="delivery.php"><button class="btn btn-info"style="float:right;">Checkout</button></a>';
	}?>
  </div>
</div>
</div>
<div style="width:250px;float:left;"><a href="index.php"><img src="http://localhost/images/logo2.jpg"style="height:90px;width:150px;cursor:pointer;"></a></div>
<br><br>
<form action="search.php" class="navbar-form" role="search">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Search" name="srch-term" id="srch-term"style="width:600px">
            <div class="input-group-btn">
                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
            </div>
        </div>
        </form>




