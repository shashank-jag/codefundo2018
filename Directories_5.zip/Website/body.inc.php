



<div class="col-sm-10">
<?php 

require 'slide_images.inc.php';?>
<div >
<?php 
//for($j=0;$j<4;$j++)
	require 'itemcat.php';
//require 'footer.inc.php';
?>
</div>
</div>







