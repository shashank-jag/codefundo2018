<!DOCTYPE html>
<html lang="en" class=" dk_fouc js no-touch rgba csstransforms csstransforms3d no-touch">
<head>
<title>Tutorial theme</title>
 <meta name="viewport" content="width=device-width, initial-scale=1">



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://localhost/js/login.js"></script>
 <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="http://localhost/js/extra.js"></script>

<script type="text/javascript"src="http://localhost/js/slide.js">
</script>

<link rel="stylesheet" href="http://localhost/onlineWebsite/style.css">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script>
$(document).ready(function(){
	$("#success-alert").hide();
	$("#success-profile").hide();
	$("#success-remove").hide();
    $("button").click(function(){
		var x=this.id;
		var z=parseInt(x,10);
		//alert(x+z);
		if(!isNaN(z)){
			//var y=x.replace('qty','');
			var y=$("#qt"+x+" > input").val();
			//alert();
			
			$("#cartist").load("http://localhost/ajax_data.php?q="+this.id+"&value="+y);
		}
    });
	$(".nav-tabs a").click(function(){
        $(this).tab('show');
    });
	$('#cartist').on('click', 'button', function(){
		var x=this.id;
		if(x.indexOf('b')!=-1){
			var y=x.replace('b','');
			var quantity=parseInt($("#"+y).text(),10);
			var product_id=x.substring(8,x.lenght);
			if(quantity<10)
			$("#"+y).load("http://localhost/increase_item.php?q="+product_id+"&value=1");
			
		}
		else if(x.indexOf('m')!=-1){
			var y=x.replace('m','')
			var quantity=parseInt($("#"+y).text(),10);
			var product_id=x.substring(8,x.lenght);
			if(quantity>1)
				$("#"+y).load("http://localhost/increase_item.php?q="+product_id+"&value=-1");
		}
	});
	$('#cartist').on('click', 'img[id^="cros"]', function(){
		var x=this.id;
		var y=x.replace('cros','');
		//var product_id=x.substring(8,x.lenght);
		$('#cartist').load("http://localhost/ajax_data.php?q="+y+"&value=d");
});
});

</script>
</head>
<body>
<div id="wrapper">
<div id="header">
<?php require 'header_design.php';?>
</div>