<div id="wrapper >
<?php require 'header.php';?>

<div id="main_body">
<?php
echo '<div class="container-fluid">
<div class="row">';
require 'site_header.inc.php';
 //echo '</div><div>';
//require 'item_page.php';
//require 'item.php';

//require 'site_header.inc.php';
require 'body.inc.php';
//require 'footer.inc.php';
?>

</body>
</div></div>
</div>
<br><br>
    <div class="footer"><br>&nbsp&nbsp&nbsp&nbspCopyright © 2016 Eproware. All Rights Reserved. </div>
</div>
