<?php
	require 'core.inc.php';

require 'connect.inc.php';
//if(!@mysql_connect('localhost','root','')||!@mysql_select_db('grocery'))
//die('couldnt');
$q = $_REQUEST["q"];
$value=$_REQUEST["value"];
if(isset($_SESSION['user_id'])){
	if($value=='d')
		mysqli_query($link,"DELETE FROM `items_purchased` WHERE `product_id`='".$q."' AND `user_id`='".$_SESSION['user_id']."'");
	else{
		$temp=mysqli_query($link,"SELECT * FROM `items_purchased` where user_id='".$_SESSION['user_id']."' AND product_id='".$q."'");
		if(mysqli_num_rows($temp)>0){
			mysqli_query($link,"UPDATE `items_purchased` SET `quantity`=`quantity`+".$value." WHERE `product_id`=".$q." AND `user_id`='".$_SESSION['user_id']."'");
		}
		else{
			mysqli_query($link,"INSERT INTO `items_purchased` VALUES (".$_SESSION['user_id'].",".$q.",".$value.")");
		}
	}		
	$no_of_products=mysqli_query($link,"SELECT `product_id`,`quantity` FROM `items_purchased` where user_id='".$_SESSION['user_id']."'");
	$price=0;
	if(mysqli_num_rows($no_of_products)>0){
	while( $product_id = mysqli_fetch_assoc($no_of_products)){
	$result = mysqli_query($link,"SELECT * FROM `grocery` where id='".$product_id['product_id']."'");  
	$row = mysqli_fetch_assoc( $result);
		echo '<div class="cart_item"style="height:60px;"><a href="item_page.php?item_id='.$row['id'].'"><img src="http://localhost/images/'.$row['image'].'"class="cart_img"></a>
		<img id="cros'.$row['id'].'" src="http://localhost/images/cross_icon.jpg"class="cart_cross_icon">
		<div style="float:right;"><button class="inc_dic"id="inc_dicb'.$row['id'].'">+</button><br>
		<div style="background-color:#E8E8E8;"class="inc_dic"id="inc_dic'.$row['id'].'">'.$product_id['quantity'].'</div><button class="inc_dic" id="inc_dicm'.$row['id'].'">-</button>
		</div>&nbsp&nbsp'.$row['productname'].'<br><b>&nbsp&nbspRs '.$row['my_price'].'&nbsp;&nbsp;&nbsp; <strike style="font-size:15px;color:red;">Rs '.$row['actual_price'].'</strike></b>
		</div><br>';
		$price+=$row['my_price']*$product_id['quantity'];
    }
	}
	else echo 'Your Cart is Empty';
	echo '<script>document.getElementById("total").innerHTML="'.$price.'";
        document.getElementById("total_items").innerHTML="'.mysqli_num_rows($no_of_products).'";</script>';
		if($value=='d'){
			 echo '<script>$(document).ready (function(){
                $("#success-remove").alert();
                $("#success-remove").fadeTo(1000, 500).slideUp(500, function(){
               $("#success-remove").hide();
                });   
		});</script>';
		}
		else {
			echo '<script>$(document).ready (function(){
                $("#success-alert").alert();
                $("#success-alert").fadeTo(1000, 500).slideUp(500, function(){
               $("#success-alert").hide();
                });   
		});</script>';
		}
}
else{
	echo '<script>alert("Please Login or Register to add items to cart");</script>';
}
  //mysql_close($link);
  //echo $row["productname"];
?>