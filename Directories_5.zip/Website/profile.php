<?php require 'header.php';?>
<div id="main_body">
<?php
if(isset($_POST['NameP'])&&!empty($_POST['NameP'])){
		$query="UPDATE `user` SET `Mobile`=".$_POST['ContactP'].",`Name`='".$_POST['NameP']."',`Country`='".$_POST['CountryP']."',`State`='".$_POST['StateP']."',`City`='".$_POST['CityP']."',`Pincode`='".$_POST['PincodeP']."',`Address`='".$_POST['AddressP']."' WHERE user_id=".$_SESSION['user_id']."";
		if($run=mysqli_query($link,$query)){
			echo '<script>$(document).ready (function(){
                $("#success-profile").alert();
                $("#success-profile").fadeTo(1000, 500).slideUp(500, function(){
               $("#success-profile").hide();
                });   
		});</script>';
			}
		else{
			echo '<script>alert("Please Fill all details");</script>';
		}
}

?>

<div class="panel panel-default" >
    <div class="panel-body"style="height:900px;width:800px; margin:0 auto;">
<div class="user_pro" style="width:500p;">
  <ul class="nav nav-tabs">
    <li class="active"><a href="#home">Profile</a></li>
    <li><a href="#menu1">Change Password</a></li>
    <li><a href="#menu2">My Orders</a></li>

  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
    
    <div class="panel panel-default">
    <div class="panel-body"><form role="form"action="<?php echo $current_file;?>" id="login" method="POST" >
			<div class="form-group">
				<label for="email">Email</label>
				<input type="email" id="username"  disabled name="EmailP"class="form-control" placeholder="<?php echo $_SESSION["Email"];?>">
			</div>
<?php
$query="SELECT * FROM `user` WHERE user_id=".$_SESSION['user_id']."";
$run=mysqli_query($link,$query);
$row_profile=mysqli_fetch_assoc($run);
echo'			<div class="form-group">
				<label for="text">Name</label>
				<input type="text" name="NameP"class="form-control" id="pwd"value="'.$row_profile['Name'].'" >
			</div>

			<div class="form-group">
				<label >Address</label>
				<input type="text" name="AddressP"class="form-control" id="pwd" value="'.$row_profile['Address'].'">
			</div>
			<div class="form-group">
				<label for="pwd">Country</label>
				<input type="text" name="CountryP"class="form-control" id="pwd" value="'.$row_profile['Country'].'">
			</div>
			<div class="form-group">
				<label for="pwd">State</label>
				<input type="text" name="StateP"class="form-control" id="pwd" value="'.$row_profile['State'].'">
			</div>
			<div class="form-group">
				<label for="pwd">City</label>
				<input type="text" name="CityP"class="form-control" id="pwd" value="'.$row_profile['City'].'">
			</div><div class="form-group">
				<label for="pwd">Pincode</label>
				<input type="number" name="PincodeP"class="form-control" id="pwd" value="'.$row_profile['Pincode'].'">
			</div>
			
			<div class="form-group">
			<label for="sel1">Gender </label>
			<select class="form-control" id="sel1">
			<option>Male</option>
			<option>Female</option>
			</select>
			</div>
			
			<div class="form-group">
				<label for="DOB">Date of Birth</label>
				<input type="date" name="Password"class="form-control" id="pwd" >
			</div>
			<div class="form-group">
				<label for="pwd">Contact No.</label>
				<input type="text" name="ContactP"class="form-control" id="pwd" value="'.$row_profile['Mobile'].'">
			</div>
			<br><button style="float:right;"type="submit" class="btn btn-info">Save</span></button>
		  </form></div>
  </div>
     
    </div>
    <div id="menu1" class="tab-pane fade">
    <div class="panel panel-default">
    <div class="panel-body">
      <form role="form"action="<?php echo $current_file;?>" id="login" method="POST" >
			<div class="form-group">
				<label for="email">Old Password</label>
				<input type="password" id="username"   name="Email"class="form-control" >
			</div>
			<div class="form-group">
				<label for="text">New Password</label>
				<input type="password" name="Password"class="form-control" id="pwd" >
			</div>
			<div class="form-group">
				<label for="pwd">Change Password</label>
				<input type="password" name="Password"class="form-control" id="pwd" >
			</div>
			<br><button style="float:right;"type="submit" class="btn btn-info">Save</span></button>
		  </form>
    </div></div>
     
    </div>
    <div id="menu2" class="tab-pane fade">
      <div class="panel panel-default">
    <div class="panel-heading">Order No.&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
	Date&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
	Items&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspAmount</div>
    <div class="panel-body">No records Found</div>
  </div>
      
    </div>
   
  </div>
</div>
</div>
  </div>
  ';?></div>