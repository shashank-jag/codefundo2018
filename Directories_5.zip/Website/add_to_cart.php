
<div class="dropdown" style="float:right;">
  <button class="dropbtn">Right</button>
  <div class="dropdown-content">
  <span id="cartist">
    <div class="cart_item"><img src="bourn.jpg" style="width:70px;height:70px;float:left;">
	<img src="cross_icon.jpg"style="width:20px;height:20px;margin-top:20px;float:right;">
	<div style="float:right;"><button class="inc_dic"id="in_dicb">+</button><br>
	<div style="background-color:#E8E8E8;"class="inc_dic"id="inc_dic">1</div><button class="inc_dic" id="in_dicm">-</button>
	</div>Product Name<br>Product Description<br><br><b>Rs 256&nbsp;&nbsp;&nbsp; <strike style="font-size:15px;color:red;">Rs 280</strike>
	</div>
	<br>
    <div class="cart_item"><img src="bourn.jpg" style="width:70px;height:70px;float:left;">
	<img src="cross_icon.jpg"style="width:20px;height:20px;margin-top:20px;float:right;">
	<div style="float:right;"><button class="inc_dic"id="inc_dicb">+</button><br>
	<div style="background-color:#E8E8E8;"class="inc_dic"id="in_dic">1</div><button class="inc_dic" id="inc_dicm">-</button>
	</div>Product Name<br>Product Description<br><br><b>Rs 256&nbsp;&nbsp;&nbsp; <strike style="font-size:15px;color:red;">Rs 280</strike>
	</div>
	<br>
	<div class="cart_item"><img src="bourn.jpg" style="width:70px;height:70px;float:left;">
	<img src="cross_icon.jpg"style="width:20px;height:20px;margin-top:20px;float:right;">
	<div style="float:right;"><button class="inc_dic"id="inc_dicb">+</button><br>
	<div style="background-color:#E8E8E8;"class="inc_dic"id="inc_dic">1</div><button class="inc_dic" id="inc_dicm">-</button>
	</div>Product Name<br>Product Description<br><br><b>Rs 256&nbsp;&nbsp;&nbsp; <strike style="font-size:15px;color:red;">Rs 280</strike>
	</div>
	  </span>
  </div>

</div>

<div id="div1"><h2>Let jQuery AJAX Change This Text</h2></div>

<button>Get External Content</button>

