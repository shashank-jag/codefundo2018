#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <ctime>    // For time()
#include <cstdlib>  // For srand() and rand()


using namespace std;

int rn(){
	return (rand() % 10) + 1;
}

string getRan10(){
	int r = rn();
	string ret="";
	while(r){
		ret = char('0' + (r%10)) + ret;
		r/=10;
	}
	return ret;
}

string getRan(){
	int t = rn()%3;
	if(t==2)return "Consumer";
	if(t)return "Farmer";
	return "FPO";
}

string getRanMob(){
	string ret;
	for(int i=0;i<10;i++)
		ret+= (rn()+'0'-1);
	return ret;
}

string getType(){
	string ret = "Producer of different ";
	//int r = rn()%4+1;
	if(rn()%2)ret+="fruits, ";
	if(rn()%2)ret+="grains, ";
	if(rn()%2)ret+="vegetables, ";
	// r = rn()%2+1;
	if(rn()%2)ret+="dairy products, ";
	if(rn()%2)ret+="poultry, ";
	// cout<<endl<<"*******"<< ret<<endl;
	return ret;
}

bool getLine(string &inp){
	getline(cin,inp);
	if(inp.size())return true;
	return getLine(inp); 
}

int main(){
	srand(time(0)); 
	while(1){
		string fin = "INSERT INTO `user` (`name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES (";
	// cout<<"name ";
	string name;cin>>name;
	if(name=="end")break;
	string type = getRan();
	fin+= "'" + name + "' , '" + name.substr(0,min(3,(int)name.size())) + "' , '" + type+ "' , '" + getRanMob() + "' , '" + name+"@mymail.com" + "' , '" ;
	// cout<<"lon lat ";
	string inp;
	getLine(inp);
	// cin>>inp;
	fin+=inp+ "' , '" ;
	// cin>>inp;
	getLine(inp);
	fin+=inp+ "' , '" ;

	// cout<<"address `address`, `City`, `State`, `Country`, `postal_code`,";
	
	getLine(inp);
	fin+=inp+ "' , '" ;
	getLine(inp);
	fin+=inp+ "' , '" ;
	getLine(inp);
	fin+=inp+ "' , '" ;
	getLine(inp);
	fin+=inp+ "' , '" ;
	getLine(inp);
	fin+=inp+ "' , " ;
	if(type == "Farmer" or type == "FPO"){
		fin+="'Organic Certified' ,'"+getType()+"',";
		if(type=="FPO")fin+="'" + getRan10()+"',";
		else fin+="NULL,";
		fin+="'"+getRan10()+"',";
		fin+="'"+getRan10()+"'";
	}
	else fin+="NULL,NULL,NULL,NULL";
	fin+=");";
	cout<<fin<<endl;
	// break;
	}
	return 0;
}