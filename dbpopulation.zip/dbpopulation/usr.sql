-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 30, 2018 at 03:38 PM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.28-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `category` varchar(250) DEFAULT NULL,
  `contact` varchar(250) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `lat` varchar(250) DEFAULT NULL,
  `longi` varchar(250) DEFAULT NULL,
  `address` text,
  `City` varchar(255) NOT NULL,
  `State` varchar(255) NOT NULL,
  `Country` varchar(255) NOT NULL,
  `postal_code` varchar(255) DEFAULT NULL,
  `Certification` text,
  `Description` text,
  `Members` varchar(255) DEFAULT NULL,
  `Ratings` varchar(255) DEFAULT '4.3',
  `FPOJoined` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES
(5, 'Jamila', '1', 'Consumer', '7415407199', 'mohammeddewaswala@gmail.com', '22.6954233', '75.85495560000004', '101 ,Nandanvan Colony ', 'Indore', 'Madhya Pradesh', 'India', '452001', '', '', NULL, NULL, NULL),
(6, 'Shanki', '1', 'Farmer', '9642991642', 'mohammeddewaswala@gmail.com', '22.8172806', '75.92890460000001', '101 ,Nandanvan Colony ', 'Indore', 'Madhya Pradesh', 'India', '452001', 'Organic Certified', 'Producer of different type of pulses', NULL, '4', '1'),
(7, 'Swakrushi Farmer Producer CO. LTD.', '1', 'FPO', '9642991642', 'mohammeddewaswala@gmail.com', '22.7258984', '75.88738899999998', '101 ,Nandanvan Colony ', 'Indore', 'Madhya Pradesh', 'India', '452001', 'Organic Certified', 'Produce different vegetables,fruits,pulses', '10', '4.3', NULL),
(8, 'Mohammed', '1', 'Farmer', '9642991642', 'mohammeddewaswala@gmail.com', '19.0759837', '72.87765590000004', '101 ,nandanvan colony mumbai', 'Mumbai', 'Maharashtra', 'india', '452001', 'Organic Certified', 'Produce different vegetables,fruits,pulses', '', '4.3', NULL),
(9, 'Choithram Market', '1', 'Market', '9642991642', 'mohammeddewaswala@gmail.com', '22.6822697', '75.8520016', 'Choitram compound near Tower Chauraha', 'Indore', 'Madhya Pradesh', 'India', '452001', '', 'Largest Market in Madhya Pradesh', '', '4.3', NULL),
(10, 'Nagaraj', '1', 'Trader', '9642991642', 'mohammeddewaswala@gmail.com', '17.445388', '78.34823019999999', 'International Institute of Information Technology, Hyderabad Campus', 'Hyderabad', 'Telangana', 'India', '500032', '', 'Dealer of grains and pulses', '', '4.3', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


INSERT INTO `user` (`username`,`name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES ('rajesh','Rajesh Mahato' , '1' , 'Farmer' , '8228121744' , 'AAA@mymail.com' , '22.8016417' , '75.85294410000006' , 'House' , 'Jakhya' , 'Indore ' , 'Madhya Pradesh ' , '453555 ' , 'Organic Certified' ,'Producer of different fruits, grains, vegetables, dairy products, ',NULL,'8','4');
INSERT INTO `user` (`username`,`name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES ('manoj' ,'manoj ji', '1' , 'FPO' , '9007100857' , 'BBB@mymail.com' , '22.797788059889843' , '76.16675646953126' , 'Sanwer Road, ' , 'Jakhya,' , 'Opposite Revati Range Gate No.1,' , 'Jakhya, Indore, Madhya Pradesh ' , '453555' , 'Organic Certified' ,'Producer of different fruits, dairy products, poultry, ','1','10','9');
INSERT INTO `user` (`username`,`name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES ('rama' ,'Rama Murti', '1' , 'FPO' , '5819232750' , 'CCC@mymail.com' , '22.544352199166514' , '75.54053576640626' , 'Farm' , 'Bhawrasla' , 'Indore, ' , 'Madhya Pradesh ' , '453555 ' , 'Organic Certified' ,'Producer of different fruits, poultry, ','7','8','4');
INSERT INTO `user` (`username`,`name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES ('DDD' , '1' , 'Consumer' , '4330311469' , 'DDD@mymail.com' , '22.69646992426142' , '76.17774279765626' , 'Highway, Near MR-10 crossing, ' , 'Bhawrasla, ' , 'Indore, ' , 'Madhya Pradesh ' , '453111' , NULL,NULL,NULL,NULL);
INSERT INTO `user` (`username`,`name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES ('EEE' , '1' , 'Consumer' , '3539955164' , 'EEE@mymail.com' , '22.361589461360673 ' , '75.96900256328126' , 'Choti Ram Chok' , 'Shiv Nagar' , 'Indore, ' , 'Madhya Pradesh ' , '452003 ' , NULL,NULL,NULL,NULL);
INSERT INTO `user` (`username`,`name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES ('DDD' , '1' , 'Consumer' , '2313119598' , 'DDD@mymail.com' , '18.774830683666913' , '73.21132884506301' , 'Washi Naka, ' , 'Sahyadri Nagar, Chembur East, ' , 'Mumbai, ' , 'Maharashtra ' , '400074' , NULL,NULL,NULL,NULL);
INSERT INTO `user` (`username`,`name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES ('EEE' , '1' , 'FPO' , '1849151806' , 'EEE@mymail.com' , '19.200759569548556' , '73.07949290756301' , '9, Sainath Mandir Chowk, ' , 'Tilak Nagar, ' , 'Chembur East, Mumbai, ' , 'Maharashtra ' , '400089' , 'Organic Certified' ,'Producer of different grains, dairy products, ','3','7','10');
INSERT INTO `user` (`username`,`name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES ('FFF' , '1' , 'Consumer' , '2247811778' , 'FFF@mymail.com' , '19.884082243342235' , '73.37612376693801' , 'B1, Jeevan Vikas Kendra Marg, ' , 'Yash Co-Operative Society, Vile Parle, Jagdish Nagar, Adarsh Vasant Bahar Society, Vile Parle East, Vile Parle,' , 'Mumbai, ' , 'Maharashtra ' , '400057' , NULL,NULL,NULL,NULL);
INSERT INTO `user` (`username`,`name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES ('GGG' , '1' , 'Consumer' , '7933881324' , 'GGG@mymail.com' , '20.02288916378877' , '73.09047923568801' , 'Oxford Ground' , 'Sector 5 Charkop, ' , 'Kandivali West' , 'Mumbai, Maharashtra ' , '400067 ' , NULL,NULL,NULL,NULL);
INSERT INTO `user` (`username`,`name`, `password`, `category`, `contact`, `email`, `lat`, `longi`, `address`, `City`, `State`, `Country`, `postal_code`, `Certification`, `Description`, `Members`, `Ratings`, `FPOJoined`) VALUES ('HHH' , '1' , 'Farmer' , '6487374558' , 'HHH@mymail.com' , '22.19963588355823' , '76.41503670029272' , '184, MDR27, ' , 'Dharampuri, ' , 'Jetpura, ' , 'Madhya Pradesh ' , '453551' , 'Organic Certified' ,'Producer of different fruits, grains, vegetables, dairy products, poultry, ',NULL,'3','10');
