<?php
function getEvent() {
  require 'connect.inc.php';
  $result = mysqli_query($link,"SELECT * FROM `Event`");
  $i=4;
  $s='<section class="mbr-cards mbr-section mbr-section-nopadding" id="features7-20" data-rv-view="211" style="background-color: rgb(239, 239, 239);">';
  $s=$s.'<div class="mbr-cards-row row">';
  while($row = mysqli_fetch_array($result)){
  	//$result1 = mysqli_query($link,"SELECT * FROM `csa` where CSA_ID='".$row['CSAID']."'");
  	//$row1 = mysqli_fetch_array($result1);
  	if($i==0){
      $s=$s.'</div>';
      $i=4;
      $s=$s.'<div class="mbr-cards-row row">';
    }
      $s=$s.'<div class="mbr-cards-col col-xs-12 col-lg-3" style="padding-top: 80px; padding-bottom: 80px;">
            <div class="container">
                <div class="card cart-block">
                    <div class="card-img"><img src="farm.jpg" height="200" width="200" class="card-img-top"></div>
                    <div class="card-block">
                        <h4 class="card-title"><font size="5">'.$row['Name'].'</font></h4>
                        <p class="card-text" ><font size="3">Start Date : '.$row['EventStart'].' <br>EventEnd : '.$row['EventEnd'].'
                        </p>
                        <div class="card-btn"><a href="#" class="btn btn-primary">MORE</a></div>
                    </div>
                </div>
            </div>
        </div>';
    $i=$i-1;
  }
  while($i!=0){
    $s=$s.'<div class="mbr-cards-col col-xs-12 col-lg-3"  padding-bottom: 80px;">
            <div class="container">
                <div class="card cart-block">
                    <div class="card-img"></div>
                    <div class="card-block">
                        <h4 class="card-title"></h4>
                        <h5 class="card-subtitle"><h5>
                        <div class="card-btn"></div>
                    </div>
                </div>
            </div>
        </div>';
        $i=$i-1;
  }
  $s=$s.'</div></section>';
  echo $s;
  mysqli_close ($link);


}


function getUserLocationEvent(){
    if(isset($_POST('City')) || isset($_POST('State')) || isset($_POST('Country'))){
        require 'connect.inc.php';
        
        if(isset($_POST(City))){
            $city = $_POST('City');
            $result1 = mysqli_query($link,"SELECT EventID FROM `Event` where City = '".$city."'");
            $row1 = mysqli_fetch_array($result1);
        }

        if(isset($_POST('State'))){
            $state = $_POST('State');
            $result2 = mysqli_query($link,"SELECT EventID FROM `Event` where State = '".$state."'");
            $row2 = mysqli_fetch_array($result2);
        }

        if(isset($_POST('Country'))){
            $country = $_POST('Country');
            $result3 = mysqli_query($link,"SELECT EventID FROM `Event` where Country = '".$country."'");
            $row3 = mysqli_fetch_array($result3);
        }
    }

    if(count($row1) > 0 && count($row2)>0 && count($row3) > 0)
        $result=array_intersect($row1,$row2,$row3);
    else
        $result=array_intersect($row2,$row3);
   
    
    $i = count($result);
    $j = 0;

    $elements=4;
    $s='<section class="mbr-cards mbr-section mbr-section-nopadding" id="features7-20" data-rv-view="211" style="background-color: rgb(239, 239, 239);">';
    $s=$s.'<div class="mbr-cards-row row">';

    while($i >= 0){
        $i = $i - 1;
        $EN = mysqli_query($link,"SELECT * FROM `Event` where EventID = ".$result[$j]."");
        $j = $j + 1;

        $event = mysqli_fetch_array($EN);
        
        if($elements==0){
          $s=$s.'</div>';
          $elements=4;
          $s=$s.'<div class="mbr-cards-row row">';
        }


        $s=$s.'<div class="mbr-cards-col col-xs-12 col-lg-3" style="padding-top: 80px; padding-bottom: 80px;">
            <div class="container">
                <div class="card cart-block">
                    <div class="card-img"><img src="farm.jpg" height="200" width="200" class="card-img-top"></div>
                    <div class="card-block">
                        <h4 class="card-title"><font size="5">'.$event['Name'].'</font></h4>
                        <p class="card-text" ><font size="3">Start Date : '.$event['EventStart'].' <br>EventEnd : '.$event['EventEnd'].'
                        </p>
                        <div class="card-btn"><a href="#" class="btn btn-primary">MORE</a></div>
                    </div>
                </div>
            </div>
        </div>';
    $elements=$elements-1;
  }
  while($elements!=0){
    $s=$s.'<div class="mbr-cards-col col-xs-12 col-lg-3"  padding-bottom: 80px;">
            <div class="container">
                <div class="card cart-block">
                    <div class="card-img"></div>
                    <div class="card-block">
                        <h4 class="card-title"></h4>
                        <h5 class="card-subtitle"><h5>
                        <div class="card-btn"></div>
                    </div>
                </div>
            </div>
        </div>';
        $elements=$elements-1;
  }
  $s=$s.'</div></section>';
  echo $s;
  mysqli_close ($link);  
        
    }
    
    


}



function getUserInfo(){
    
    require 'connect.inc.php';
    $result = mysqli_query($link,"SELECT * FROM `user` where id = 5");
    $row = mysqli_fetch_array($result);
    echo '
    <div class="header_1">
    <img src="profile.jpg" width="250" height="250" alt="Your Name" />
    </div>
    <!-- End Profile Image Section -->
     
    <!-- Begin Profile Information Section -->
    <div class="header_2">
     
    <h1><span>'.$row['name'].'</span></h1>
    <h3>Profession</h3>
     
    <ul class="info_1">
    <li class="address">'.$row['address'].'</li>
    </ul> 
    <ul class="info_2">
    <li class="phone">'.$row['contact'].'</li>
    <li class="email"><a href="mailto:your-email@gmail.com">'.$row['email'].'</a></li>
    <li class="site_url"><a href="http://www.webcodepro.net/about.php" title="www.your-website.com">www.your-website.com</a></li>
    <li class="twitter"><a href="http://twitter.com/twitter-screen-name" title="Follow Me on Twitter">@twitter-screen-name</a></li>
    </ul>
     
    </div>
    ';
}

function getUserInterests(){

  require 'connect.inc.php';
  $result = mysqli_query($link,"SELECT Interest FROM `Interests` where id = 5");
   $row = mysqli_fetch_array($result);
  echo '  
    <!-- Begin Interests Section -->
     
    <dl>
    <dt>Interests</dt>
    <dd>
     
    <section id="skills">
    <ul class="list1">';
  while($row = mysqli_fetch_array($result)){
    echo '
      <li>'.$row['Interest'].'</li>';
    }
    echo '
    </ul>
    </section>
     
    </dd>
    </dl>
    <!-- End Interests Section -->';

}

function getEventDetails(){
  //echo '<script>alert("hello")</script>';
  require 'connect.inc.php';
  $result = mysqli_query($link,"SELECT * FROM `Event` where EventID = 1");
  $row = mysqli_fetch_array($result);
  
  $Org = mysqli_query($link,"SELECT * FROM `user` where id = ".$row['OrganiserID']."");
  $res = mysqli_fetch_array($Org);
  
  echo '  
    <div class="header_1">
    <img src="profile.jpg" width="250" height="250" alt="Your Name" />
    </div>
    <!-- End Profile Image Section -->
     
    <!-- Begin Profile Information Section -->
    <div class="header_2">
     
    <h1><span>'.$row['Name'].'</span></h1>
    <h3>Profession</h3>
     
    <ul class="info_1">
    <li class="address">'.$row['Address'].' ,'.$row['City'].' ,'.$row['State'].' ,'.$row['Country'].' </li>
    </ul> 
    <ul class="info_2">
    <li class="Event">'.$res['name'].'</li>
    <li class="Event">'.$row['EventStart'].'</li>
    <li class="Event">'.$row['EventEnd'].'</li>
    <li class="Event">'.$row['Ticket'].'</li>
    <li class="site_url"><a href="http://www.webcodepro.net/about.php" title="www.your-website.com">'.$res[email].'</a></li>
    <li class="site_url"><a href="http://www.webcodepro.net/about.php" title="www.your-website.com">www.your-website.com</a></li>
    <li class="twitter"><a href="http://twitter.com/twitter-screen-name" title="Follow Me on Twitter">@twitter-screen-name</a></li>
    </ul>
     
    </div>
    ';
 
}  

function getEventDescription(){

  require 'connect.inc.php';
  $result = mysqli_query($link,"SELECT * FROM `Event` where EventID = 1");
  $row = mysqli_fetch_array($result);
  /*echo '<script>alert("helkklo")</script>';*/
  echo '
    <dl>
    <dt>Description:</dt>
    <dd>
 
    <section class="Description">
    '.$row['Description'].'
    </section>
 
    </dd>
    </dl>';
}

?>
