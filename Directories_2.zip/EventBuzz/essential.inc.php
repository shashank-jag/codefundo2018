<?php
session_start();
echo'<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://localhost/js/login.js"></script>
 <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="http://localhost/js/extra.js"></script>

<script type="text/javascript"src="http://localhost/js/slide.js">
</script>

<link rel="stylesheet" href="http://localhost/EventBuzz/style.css">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">


'
?>

