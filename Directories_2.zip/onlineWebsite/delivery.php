<?php require 'header.php';?>
<div id="main_body">
<style>
.user_pro {  
  width: 600px;  
  } 
</style>
<div class="panel panel-default" >
    <div class="panel-body"style="height:800px;width:800px; margin:0 auto;">

    <div class="panel panel-default">
    <div class="panel-body"><form role="form" action="index.php" id="login" method="POST" >
			<div class="form-group">
				<label for="email">Email</label>
				<input type="email" id="username"  disabled name="Email"class="form-control" placeholder="<?php echo $_SESSION["Email"];?>">
			</div>
			<?php
$query="SELECT * FROM `user` WHERE user_id=".$_SESSION['user_id']."";
$run=mysql_query($query);
$row_profile=mysql_fetch_assoc($run);
echo'			<div class="form-group">
				<label for="text">Name</label>
				<input type="text" name="NameP"class="form-control" id="pwd"value="'.$row_profile['Name'].'" >
			</div>

			<div class="form-group">
				<label >Address</label>
				<input type="text" name="AddressP"class="form-control" id="pwd" value="'.$row_profile['Address'].'">
			</div>
			<div class="form-group">
				<label for="pwd">Country</label>
				<input type="text" name="CountryP"class="form-control" id="pwd" value="'.$row_profile['Country'].'">
			</div>
			<div class="form-group">
				<label for="pwd">State</label>
				<input type="text" name="StateP"class="form-control" id="pwd" value="'.$row_profile['State'].'">
			</div>
			<div class="form-group">
				<label for="pwd">City</label>
				<input type="text" name="CityP"class="form-control" id="pwd" value="'.$row_profile['City'].'">
			</div><div class="form-group">
				<label for="pwd">Pincode</label>
				<input type="number" name="PincodeP"class="form-control" id="pwd" value="'.$row_profile['Pincode'].'">
			</div>
			<div class="form-group">
				<label for="pwd">Contact No.</label>
				<input type="text" name="ContactP"class="form-control" id="pwd" value="'.$row_profile['Mobile'].'">
			</div>';?>
			<br>
		    <div class="modal fade" id="Thankyou" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Thank You For Purchasing</h4>
        </div>
        <div class="modal-body">
          <p>Products will be delivered within 24 hours</p>
			
			
			
			<button style="float:right;"type="submit" class="btn btn-info">OK</span></button>
	
        </div>
		<br><br>
        
      </div>
      
    </div>
  </div>
		  </form><button style="float:right;" class="btn btn-info" data-toggle="modal" data-target="#Thankyou">Continue</button></div>
  </div>
  
     
    </div>
    
  </div></div>