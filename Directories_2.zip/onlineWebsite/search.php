<?php 
	$search=$_REQUEST["srch-term"];
	if($_REQUEST["srch-term"]==''){header('Location: index.php');}
	require 'header.php';
	require 'site_header.inc.php';
	echo '<div class="col-sm-10">';
	
	$query="SELECT * FROM `grocery` WHERE 	productname LIKE '%".$_REQUEST["srch-term"]."%' OR description LIKE '%".$_REQUEST["srch-term"]."%' OR category LIKE '%".$_REQUEST['srch-term']."'";
	$item = mysql_query($query);
	if(mysql_num_rows($item)>0){
	echo '&nbsp<h2 class="modal-title">&nbsp&nbspSearch result for '.$_REQUEST["srch-term"].'</h2><br><br>';
	require 'item.php';
	}
	else echo'&nbsp<h2 class="modal-title">&nbsp&nbspNo products found for Search '.$_REQUEST["srch-term"].'</h2><br><br>';

?></div>