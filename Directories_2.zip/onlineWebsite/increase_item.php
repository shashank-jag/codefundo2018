<?php
//if(!@mysql_connect('localhost','root','')||!@mysql_select_db('grocery'))
//die('couldnt');
$q = $_REQUEST["q"];
$value=$_REQUEST["value"];
	mysql_query("UPDATE `items_purchased` SET `quantity`=`quantity`+".$_REQUEST["value"]." WHERE `product_id`=".$q."");
	$row=mysql_query("SELECT `quantity` FROM `items_purchased` WHERE product_id=".$q."");
	$result = mysql_fetch_assoc($row);
	echo $result['quantity'];
	$re = mysql_query("SELECT `my_price` FROM `grocery` where id='".$q."'");
	$row2=mysql_fetch_assoc($re);
	echo '<script>var in_q=parseInt(document.getElementById("total").innerHTML);
			in_q+='.$value*$row2['my_price'].';
			document.getElementById("total").innerHTML=in_q;
	</script>';

?>