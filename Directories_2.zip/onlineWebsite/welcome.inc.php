<?php
	//if($_SESSION['user_id']!=2){
	//session_destroy();
	//header('Location: index.php');
	//}
	//else
		//unset($_SESSION['user_id']);
?>
<div style="float:right;">
<div class="drop_user-info">
  <span >Hi <?php echo $_SESSION['Email'];?></span>
  <div class="dropdown-user">
    <a href="profile.php" class="user_info">Profile</a>
	<hr>
    <div class="user_info" style="text-align:center;"><a href="logout.php" style="text-decoration: none;color:WHITE;" ><button class="onclick" >Sign out</button></a></div>
  </div>
</div>
</div>

