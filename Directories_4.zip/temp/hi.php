<?php
#require 'connect.inc.php';
				session_start();

 echo $_SESSION['lat'];
#$result = mysql_query("SELECT * FROM `DEmandTable` where id='".$product_id['product_id']."'");
#$row = mysql_fetch_assoc( $result);
#echo $row['ProductName']
?>
